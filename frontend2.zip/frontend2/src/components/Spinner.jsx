export default function Spinner() {
  return <div style={{ padding: 8 }}>Chargement…</div>
}
